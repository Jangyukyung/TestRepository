/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch18.exam05;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 *
 * @author Administrator
 */
public class WriteExample {
    public static void main(String[] args) throws FileNotFoundException, IOException, InterruptedException {
        InputStream is=new FileInputStream("src/ch18/exam05/test.txt");
       
        OutputStream os=new FileOutputStream("src/ch18/exam05/test2.txt");
       
        byte[] data=new byte[4];
        int readBytes=-1;
        while(true){
            readBytes=is.read(data);
            if(readBytes==-1) break;
            os.write(data,0,readBytes);
        }
        
        
       os.flush();
       os.close();
        //Thread.sleep(10000);
    
    }
}
