package ch06.exam11.pack1;

public class A {
	
	public int field1;
	
	public A(){
		
	}
	
	public void method(){
		
	}
}
