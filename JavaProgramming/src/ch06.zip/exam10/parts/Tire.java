package ch06.exam10.parts;

public class Tire {

}
