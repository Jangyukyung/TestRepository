package ch06.exam10.parts2;

public class Tire {

}
