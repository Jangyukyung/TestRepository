package ch06.exam10.product;

import ch06.exam10.parts.*;
//import ch06.exam10.parts.Engine;
//import ch06.exam10.parts.Tire;

public class Car {
	Engine engine=new Engine();
	Tire tire=new Tire();
}
