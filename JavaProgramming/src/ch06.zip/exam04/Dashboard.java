package ch06.exam04;

public class Dashboard {
	//Field
	
	//Constructor
	
	//Method
	void display(int speed){
		System.out.println("�뽬���尪: " +speed);
	}
}
