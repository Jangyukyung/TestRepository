package ch06.exam04;

public class Body {

}
