package ch06.homework;

public class Foot {
	//Field
	String direction;
	//Constructor
	Foot(String direction){
		this.direction=direction;
	}
	//Method
}
