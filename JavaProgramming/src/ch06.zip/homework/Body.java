package ch06.homework;

public class Body {
	//Field
	
	//Constructor
		
	//Method
}
