package ch06.exam09;

public class MemberExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Member member=new Member("ȫ�浿","111111-1234567");
		member.name="���ڹ�";
		//member.ssn="222222-1234567";
	}

}
