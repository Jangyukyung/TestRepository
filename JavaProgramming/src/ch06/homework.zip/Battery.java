package ch06.homework;

public class Battery {
	//Field
	
	//Constructor
		
	//Method
	void on(){
		System.out.println("[ Power On ]");
	}
	void off(){
		System.out.println("[ Power Off ]");
	}
}
