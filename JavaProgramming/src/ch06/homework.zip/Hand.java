package ch06.homework;

public class Hand {
	//Field
	String direction;
	//Constructor
	Hand(String direction){
		this.direction=direction;
	}
	//Constructor
		
	//Method
}
